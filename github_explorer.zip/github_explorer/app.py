"""GitHub Repository Explorer with Streamlit."""
import os
from typing import Optional

import streamlit as st
from github import Github
from git import Repo

from agents import StructureAnalysisAgent, SecurityAnalysisAgent

# Configuration
CLONE_DIR = "repositories"

def setup_page():
    """Configure the Streamlit page."""
    st.set_page_config(
        page_title="GitHub Explorer",
        page_icon="🐙",
        layout="wide"
    )
    st.title("GitHub Repository Explorer 🐙")

def get_github_client(token: str) -> Optional[Github]:
    """Create a GitHub client with the provided token."""
    try:
        client = Github(token)
        # Test the connection by getting the authenticated user
        client.get_user().login
        return client
    except Exception as e:
        st.error(f"Failed to authenticate with GitHub: {str(e)}")
        return None

def list_repositories(client: Github):
    """List repositories accessible to the authenticated user."""
    try:
        user = client.get_user()
        repos = user.get_repos()
        return [(repo.full_name, repo.clone_url, repo.default_branch) for repo in repos]
    except Exception as e:
        st.error(f"Failed to fetch repositories: {str(e)}")
        return []

def clone_repository(clone_url: str, repo_name: str, branch: str):
    """Clone a repository to local storage."""
    try:
        # Create the clone directory if it doesn't exist
        os.makedirs(CLONE_DIR, exist_ok=True)
        
        # Full path for the repository
        repo_path = os.path.join(CLONE_DIR, repo_name.replace("/", "_"))
        
        # Clone the repository
        if not os.path.exists(repo_path):
            st.info(f"Cloning repository to {repo_path}...")
            Repo.clone_from(clone_url, repo_path, branch=branch)
            st.success("Repository cloned successfully! 🎉")
        else:
            # If repository exists, pull the latest changes
            st.info("Repository already exists, pulling latest changes...")
            repo = Repo(repo_path)
            origin = repo.remotes.origin
            origin.pull()
            st.success("Repository updated successfully! 🎉")
        
        return repo_path
    except Exception as e:
        st.error(f"Failed to clone repository: {str(e)}")
        return None

def analyze_repository(repo_path: str):
    """Analyze the repository structure and security."""
    try:
        # Structure Analysis
        with st.spinner("Analyzing repository structure..."):
            st.write("## 🔍 Structure Analysis")
            structure_agent = StructureAnalysisAgent(repo_path)
            structure_result = structure_agent.analyze()
            
            # Display directory structure
            with st.expander("📁 Directory Structure", expanded=True):
                structure = next(f for f in structure_result.findings if f["component"] == "Directory Structure")["details"]
                st.json(structure)
            
            # Display key components
            with st.expander("🔑 Key Components", expanded=True):
                components = next(f for f in structure_result.findings if f["component"] == "Key Components")["details"]
                for category, files in components.items():
                    if files:
                        st.write(f"**{category.replace('_', ' ').title()}**")
                        for file in files:
                            st.write(f"- `{file}`")
        
        # Security Analysis
        with st.spinner("Scanning for vulnerabilities..."):
            st.write("## 🛡️ Security Analysis")
            security_agent = SecurityAnalysisAgent(repo_path)
            security_result = security_agent.analyze()
            
            # Display executive summary
            st.write("### 📊 Executive Summary")
            analysis = next(f for f in security_result.findings if f["component"] == "Security Analysis")["details"]
            st.markdown(analysis)
            
            # Display vulnerability scan results
            with st.expander("🔒 Vulnerability Scan", expanded=True):
                vuln_scan = next(f for f in security_result.findings if f["component"] == "Vulnerability Scan")["details"]
                if vuln_scan.get('error'):
                    st.error(f"Error during vulnerability scan: {vuln_scan['error']}")
                elif vuln_scan['total_count'] == 0:
                    st.success("No known vulnerabilities found!")
                else:
                    st.warning(f"Found {vuln_scan['total_count']} potential vulnerabilities")
                    for vuln in vuln_scan['vulnerabilities']:
                        with st.expander(f"⚠️ {vuln['package']} ({vuln['installed_version']})"): 
                            st.write(f"**Vulnerability ID:** {vuln['vulnerability_id']}")
                            st.write(f"**Affected Versions:** {vuln['vulnerable_version']}")
                            st.write(f"**Description:** {vuln['description']}")
            
            # Display security recommendations in a separate row
            st.write("### 💡 Security Recommendations")
            recommendations_container = st.container()
            with recommendations_container:
                for rec in security_result.recommendations:
                    st.warning(rec)
        
        # Detailed Analysis Section
        st.write("## 📊 Detailed Analysis")
        
        # Structure analysis details
        with st.expander("🏗️ Structure Analysis Details", expanded=True):
            analysis = next(f for f in structure_result.findings if f["component"] == "Analysis")["details"]
            if isinstance(analysis, str):
                sections = analysis.split('\n')
                current_section = None
                for line in sections:
                    if line.strip():
                        if not line.startswith(' ') and ':' in line:
                            current_section = line.strip()
                            st.subheader(current_section)
                        else:
                            st.write(line)
            else:
                st.write(analysis)
        
        # Security analysis details
        with st.expander("🔐 Security Analysis Details", expanded=True):
            analysis = next(f for f in security_result.findings if f["component"] == "Security Analysis")["details"]
            if isinstance(analysis, str):
                sections = analysis.split('\n')
                current_section = None
                for line in sections:
                    if line.strip():
                        if not line.startswith(' ') and ':' in line:
                            current_section = line.strip()
                            st.subheader(current_section)
                        else:
                            st.write(line)
            else:
                st.write(analysis)
                        
    except Exception as e:
        st.error(f"Failed to analyze repository: {str(e)}")

def main():
    """Main application."""
    setup_page()
    
    # GitHub Token (hardcoded for development)
    token = "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"
    
    if not token:
        st.info("Please enter your GitHub personal access token to continue.")
        st.markdown("""
        ### How to get a Personal Access Token:
        1. Go to GitHub Settings → Developer Settings → Personal Access Tokens → Tokens (classic)
        2. Click "Generate new token (classic)"
        3. Give it a name and select these permissions:
           - `repo` (Full control of private repositories)
           - `read:org` (Read organization information)
        4. Click "Generate token" and copy it here
        """)
        return
    
    # Initialize GitHub client
    client = get_github_client(token)
    if not client:
        return
    
    # List repositories
    repositories = list_repositories(client)
    if not repositories:
        return
    
    # Repository selection
    st.write("### Select a Repository")
    repo_names = [repo[0] for repo in repositories]
    selected_repo = st.selectbox(
        "Choose a repository to clone",
        options=repo_names,
        format_func=lambda x: x,
        placeholder="Select a repository..."
    )
    
    # Clone and analyze repository
    if selected_repo:
        selected_info = next((repo for repo in repositories if repo[0] == selected_repo), None)
        if selected_info:
            # Clone repository button
            if st.button("Clone Repository"):
                repo_path = clone_repository(selected_info[1], selected_info[0], selected_info[2])
                if repo_path:
                    st.write(f"Repository cloned to: `{repo_path}`")
                    st.session_state['current_repo_path'] = repo_path
            
            # Analyze repository button (only show if repository is cloned)
            if 'current_repo_path' in st.session_state:
                st.write("")
                if st.button("Analyze Repository"):
                    analyze_repository(st.session_state['current_repo_path'])

if __name__ == "__main__":
    main()
