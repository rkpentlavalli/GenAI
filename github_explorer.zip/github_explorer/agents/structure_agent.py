"""Agent for analyzing repository structure."""
import os
from typing import Dict, List, Optional

from crewai import Agent, Crew, Task

from .base_agent import AnalysisResult, BaseAnalysisAgent


class StructureAnalysisAgent(BaseAnalysisAgent):
    """Agent responsible for analyzing repository structure."""

    def __init__(self, repo_path: str, openai_api_key: Optional[str] = None):
        """Initialize the structure analysis agent."""
        super().__init__(repo_path, openai_api_key)
        self.ignored_dirs = {'.git', '__pycache__', 'node_modules', '.idea', '.vscode'}
        self.key_files = {
            'package_managers': {'requirements.txt', 'package.json', 'Cargo.toml', 'go.mod'},
            'config_files': {'.env.example', 'config.py', 'settings.py'},
            'entry_points': {'main.py', 'app.py', 'index.js', 'server.js'},
            'documentation': {'README.md', 'docs/', 'CONTRIBUTING.md'}
        }
    
    def _scan_directory(self, path: str, level: int = 0, max_level: int = 5) -> Dict:
        """Scan directory and create a tree structure."""
        if level > max_level:
            return {"name": os.path.basename(path), "type": "directory", "truncated": True}
        
        try:
            items = os.listdir(path)
        except PermissionError:
            return {"name": os.path.basename(path), "type": "directory", "error": "Permission denied"}
        
        structure = {
            "name": os.path.basename(path),
            "type": "directory",
            "children": []
        }
        
        for item in sorted(items):
            if item in self.ignored_dirs:
                continue
                
            full_path = os.path.join(path, item)
            if os.path.isdir(full_path):
                child = self._scan_directory(full_path, level + 1, max_level)
                structure["children"].append(child)
            else:
                structure["children"].append({
                    "name": item,
                    "type": "file"
                })
        
        return structure
    
    def _identify_key_components(self) -> Dict[str, List[str]]:
        """Identify key components in the repository."""
        found_components = {category: [] for category in self.key_files.keys()}
        
        for root, _, files in os.walk(self.repo_path):
            if any(ignored in root for ignored in self.ignored_dirs):
                continue
                
            for file in files:
                for category, patterns in self.key_files.items():
                    if file in patterns or any(
                        pattern.rstrip('/') in root for pattern in patterns
                        if pattern.endswith('/')
                    ):
                        rel_path = os.path.relpath(os.path.join(root, file), self.repo_path)
                        found_components[category].append(rel_path)
        
        return found_components
    
    def analyze(self) -> AnalysisResult:
        """Perform structure analysis of the repository."""
        # Create an agent for structure analysis
        structure_agent = self.create_agent(
            role="Repository Structure Analyst",
            goal="Analyze and understand repository structure and architecture",
            backstory="Expert in software architecture and codebase organization. "
                     "Skilled at identifying patterns and providing insights about code structure."
        )
        
        # Scan directory structure
        directory_structure = self._scan_directory(self.repo_path)
        
        # Identify key components
        key_components = self._identify_key_components()
        
        # Create analysis task
        analysis_task = self.create_task(
            f"""Analyze the following repository structure and components:
            Directory Structure: {directory_structure}
            Key Components: {key_components}
            
            Provide insights about:
            1. The overall architecture pattern
            2. Project organization
            3. Key entry points and configurations
            4. Recommendations for improvement
            
            Format your response as a structured analysis with findings and recommendations.
            """,
            structure_agent,
            expected_output="""A structured analysis of the repository containing:
            1. Architecture Pattern Analysis
            2. Project Organization Overview
            3. Key Components and Entry Points
            4. Specific Recommendations for Improvement
            
            The response should be well-formatted markdown with clear sections and bullet points."""
        )
        
        # Create and execute crew
        crew = Crew(
            agents=[structure_agent],
            tasks=[analysis_task],
            verbose=True
        )

        # Execute analysis
        analysis_result = crew.kickoff()
        
        # Parse recommendations from analysis result
        # The LLM output should contain sections with recommendations
        recommendations = []
        if isinstance(analysis_result, str):
            sections = analysis_result.split('\n')
            in_recommendations = False
            for line in sections:
                if 'recommendation' in line.lower():
                    in_recommendations = True
                    continue
                if in_recommendations and line.strip().startswith('-'):
                    recommendations.append(line.strip()[2:].strip())
                elif in_recommendations and line.strip() and not line.startswith(' '):
                    in_recommendations = False
        
        # Return structured results
        return AnalysisResult(
            category="Structure Analysis",
            findings=[
                {"component": "Directory Structure", "details": directory_structure},
                {"component": "Key Components", "details": key_components},
                {"component": "Analysis", "details": analysis_result}
            ],
            recommendations=recommendations if recommendations else [
                "Analyzing project structure and patterns...",
                "Identifying potential improvements in organization...",
                "Checking for best practices in code structure..."
            ]
        )
