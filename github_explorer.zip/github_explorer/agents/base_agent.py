"""Base agent for repository analysis."""
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from crewai import Agent, Task
from langchain.tools import Tool, tool
from langchain_openai import ChatOpenAI
from pydantic import BaseModel


class AnalysisResult(BaseModel):
    """Structure for analysis results."""
    category: str
    findings: List[Dict]
    recommendations: List[str]


class BaseAnalysisAgent(ABC):
    """Base class for repository analysis agents."""
    
    def __init__(self, repo_path: str, openai_api_key: Optional[str] = None):
        """Initialize the agent with repository path and optional API key."""
        self.repo_path = repo_path
        self.openai_api_key = "sk-story-telling-mouli-jV4v9SWHTwNtgJidCF2bT3BlbkFJgXPJ7iLrdfYEU45cPYhm"
        self.llm = self._initialize_llm()
    
    def _initialize_llm(self) -> ChatOpenAI:
        """Initialize the language model."""
        return ChatOpenAI(
            model="gpt-4",
            temperature=0,
            api_key=self.openai_api_key
        )
    
    @abstractmethod
    def analyze(self) -> AnalysisResult:
        """Perform the analysis. To be implemented by specific agents."""
        pass
    
    def create_agent(self, role: str, goal: str, backstory: str) -> Agent:
        """Create a CrewAI agent with specific role and goal."""
        return Agent(
            role=role,
            goal=goal,
            backstory=backstory,
            llm=self.llm,
            verbose=True
        )
    
    def create_task(self, description: str, agent: Agent, expected_output: str = None) -> Task:
        """Create a task for an agent."""
        # Get all tools from the instance
        tools = []
        for attr_name in dir(self):
            attr = getattr(self, attr_name)
            if hasattr(attr, '_tool'):
                # Create a wrapper that handles the tool_input
                def tool_wrapper(tool_input: Dict = None, _func=attr, _self=self):
                    return _func(_self, tool_input)
                
                tools.append(
                    Tool(
                        name=getattr(attr, '_tool', {}).get('name', attr_name),
                        description=attr.__doc__ or '',
                        func=tool_wrapper
                    )
                )
        
        # Add tools to agent
        agent.tools = tools
        
        return Task(
            description=description,
            agent=agent,
            expected_output=expected_output or "A detailed analysis with findings and recommendations."
        )
