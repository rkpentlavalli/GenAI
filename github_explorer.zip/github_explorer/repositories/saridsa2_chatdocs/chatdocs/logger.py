import logging

logger = logging.getLogger("chatdocs")
